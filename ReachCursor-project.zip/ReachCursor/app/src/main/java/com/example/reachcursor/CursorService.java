package com.example.reachcursor;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class CursorService extends AccessibilityService {
    private static final float GAIN = 2.6f;      // cursor speed vs. finger movement
    private static final int MODE_CLICK = 0, MODE_LONG = 1, MODE_SCROLL = 2;

    private WindowManager wm;
    private CursorView cursor;
    private PadView pad;
    private float cx, cy, density;
    private int sw, sh;

    @Override public void onServiceConnected() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density;
        cx = sw / 2f; cy = sh / 2f;

        WindowManager.LayoutParams cp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        cursor = new CursorView(this);
        wm.addView(cursor, cp);

        int size = (int) (160 * density);
        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        pp.x = (int) (8 * density); pp.y = (int) (8 * density);
        pad = new PadView(this);
        wm.addView(pad, pp);
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (wm == null) return;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels;
        cx = Math.max(0, Math.min(sw - 1, cx));
        cy = Math.max(0, Math.min(sh - 1, cy));
        if (cursor != null) cursor.invalidate();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(android.content.Intent i) {
        try { if (cursor != null) wm.removeView(cursor); } catch (Exception ignored) { }
        try { if (pad != null) wm.removeView(pad); } catch (Exception ignored) { }
        cursor = null; pad = null;
        return super.onUnbind(i);
    }

    // ---------- actions at the cursor position ----------
    private void act(int mode, boolean forward) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        AccessibilityNodeInfo n = find(root, (int) cx, (int) cy, mode);
        if (n == null) return;
        switch (mode) {
            case MODE_CLICK: n.performAction(AccessibilityNodeInfo.ACTION_CLICK); break;
            case MODE_LONG:  n.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK); break;
            default: n.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                                             : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        }
    }

    /** Deepest node under (x,y) that supports the requested action. */
    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, int x, int y, int mode) {
        if (node == null) return null;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.contains(x, y) && node.getChildCount() == 0) return null;
        for (int i = node.getChildCount() - 1; i >= 0; i--) {   // top-most child first
            AccessibilityNodeInfo hit = find(node.getChild(i), x, y, mode);
            if (hit != null) return hit;
        }
        if (!r.contains(x, y) || !node.isEnabled() || !node.isVisibleToUser()) return null;
        boolean ok = mode == MODE_CLICK ? node.isClickable()
                   : mode == MODE_LONG ? node.isLongClickable() : node.isScrollable();
        return ok ? node : null;
    }

    // ---------- views ----------
    private class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrow = new Path();
        CursorView(Context c) {
            super(c);
            fill.setColor(Color.WHITE);
            line.setColor(Color.BLACK); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2 * density);
            float d = density;
            arrow.moveTo(0, 0); arrow.lineTo(0, 22 * d); arrow.lineTo(6 * d, 17 * d);
            arrow.lineTo(11 * d, 28 * d); arrow.lineTo(15 * d, 26 * d); arrow.lineTo(10 * d, 15 * d);
            arrow.lineTo(18 * d, 15 * d); arrow.close();
        }
        @Override protected void onDraw(Canvas c) {
            c.save(); c.translate(cx, cy);
            c.drawPath(arrow, fill); c.drawPath(arrow, line);
            c.restore();
        }
    }

    private class PadView extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG), edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float lx, ly, scrollAcc, travel;
        private long down;
        private boolean multi;

        PadView(Context c) {
            super(c);
            bg.setColor(0x55222222);
            edge.setColor(0x99FFFFFF); edge.setStyle(Paint.Style.STROKE); edge.setStrokeWidth(2 * density);
        }
        @Override protected void onDraw(Canvas c) {
            RectF r = new RectF(2 * density, 2 * density, getWidth() - 2 * density, getHeight() - 2 * density);
            c.drawRoundRect(r, 16 * density, 16 * density, bg);
            c.drawRoundRect(r, 16 * density, 16 * density, edge);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    lx = e.getX(); ly = e.getY(); travel = 0; scrollAcc = 0; multi = false;
                    down = e.getEventTime();
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    multi = true; ly = e.getY(); scrollAcc = 0;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getX() - lx, dy = e.getY() - ly;
                    lx = e.getX(); ly = e.getY();
                    travel += Math.abs(dx) + Math.abs(dy);
                    if (e.getPointerCount() >= 2) {
                        scrollAcc += dy;
                        if (Math.abs(scrollAcc) > 40 * density) {
                            act(MODE_SCROLL, scrollAcc < 0);   // finger up => content forward
                            scrollAcc = 0;
                        }
                    } else if (!multi) {
                        cx = Math.max(0, Math.min(sw - 1, cx + dx * GAIN));
                        cy = Math.max(0, Math.min(sh - 1, cy + dy * GAIN));
                        if (cursor != null) cursor.invalidate();
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!multi && travel < 12 * density) {
                        long held = e.getEventTime() - down;
                        act(held >= 500 ? MODE_LONG : MODE_CLICK, true);
                    }
                    break;
            }
            return true;
        }
    }
}
