package com.example.reachcursor;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class CursorService extends AccessibilityService {
    private static final float GAIN = 2.6f;      // cursor speed vs. finger movement
    private static final int MODE_CLICK = 0, MODE_LONG = 1, MODE_SCROLL = 2;

    private WindowManager wm;
    private CursorView cursor;
    private PadView pad;
    private BubbleView bubble;
    private WindowManager.LayoutParams padParams, bubbleParams;
    private SharedPreferences prefs;
    private final Handler handler = new Handler();
    private boolean padShown;
    private int fadeMs = 3000;                   // 0 = never fade
    private float cx, cy, density;
    private int sw, sh, padSize, bubbleSize;

    private final Runnable fadeRunnable = new Runnable() {
        @Override public void run() {
            if (cursor != null) cursor.animate().alpha(0f).setDuration(400).start();
        }
    };

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
        new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                loadPrefs();
            }
        };

    @Override public void onServiceConnected() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density;
        cx = sw / 2f; cy = sh / 2f;

        // Cursor layer (full screen, never touchable)
        WindowManager.LayoutParams cp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        cursor = new CursorView(this);
        cursor.setAlpha(0f);
        wm.addView(cursor, cp);

        // Touchpad (added only when shown)
        padSize = (int) (160 * density);
        padParams = new WindowManager.LayoutParams(
            padSize, padSize, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        padParams.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        padParams.x = (int) (8 * density); padParams.y = (int) (8 * density);
        pad = new PadView(this);

        // Small round button that shows/hides the touchpad
        bubbleSize = (int) (44 * density);
        bubbleParams = new WindowManager.LayoutParams(
            bubbleSize, bubbleSize, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = prefs.getInt("bubble_x", sw - bubbleSize - (int) (8 * density));
        bubbleParams.y = prefs.getInt("bubble_y", sh / 2);
        clampBubble();
        bubble = new BubbleView(this);
        wm.addView(bubble, bubbleParams);

        loadPrefs();
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
    }

    private void loadPrefs() {
        if (prefs == null) return;
        fadeMs = prefs.getInt("fade_ms", 3000);
        if (bubble != null) bubble.setAlpha(prefs.getInt("bubble_alpha", 80) / 100f);
        if (padShown) { showCursor(); scheduleFade(); }
    }

    // ---------- cursor visibility ----------
    private void showCursor() {
        handler.removeCallbacks(fadeRunnable);
        if (cursor == null) return;
        cursor.animate().cancel();
        cursor.setAlpha(1f);
    }
    private void scheduleFade() {
        handler.removeCallbacks(fadeRunnable);
        if (fadeMs > 0) handler.postDelayed(fadeRunnable, fadeMs);
    }
    private void hideCursorNow() {
        handler.removeCallbacks(fadeRunnable);
        if (cursor == null) return;
        cursor.animate().cancel();
        cursor.setAlpha(0f);
    }

    private void togglePad() {
        try {
            if (padShown) {
                wm.removeView(pad);
                padShown = false;
                hideCursorNow();
            } else {
                wm.addView(pad, padParams);
                padShown = true;
                showCursor();
                scheduleFade();
            }
        } catch (Exception ignored) { }
    }

    private void clampBubble() {
        bubbleParams.x = Math.max(0, Math.min(sw - bubbleSize, bubbleParams.x));
        bubbleParams.y = Math.max(0, Math.min(sh - bubbleSize, bubbleParams.y));
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (wm == null) return;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels;
        cx = Math.max(0, Math.min(sw - 1, cx));
        cy = Math.max(0, Math.min(sh - 1, cy));
        clampBubble();
        padParams.x = Math.max(0, Math.min(sw - padSize, padParams.x));
        padParams.y = Math.max(0, Math.min(sh - padSize, padParams.y));
        try {
            wm.updateViewLayout(bubble, bubbleParams);
            if (padShown) wm.updateViewLayout(pad, padParams);
        } catch (Exception ignored) { }
        if (cursor != null) cursor.invalidate();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(android.content.Intent i) {
        handler.removeCallbacks(fadeRunnable);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        try { if (cursor != null) wm.removeView(cursor); } catch (Exception ignored) { }
        try { if (padShown) wm.removeView(pad); } catch (Exception ignored) { }
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) { }
        cursor = null; pad = null; bubble = null; padShown = false;
        return super.onUnbind(i);
    }

    // ---------- actions at the cursor position ----------
    private void act(int mode, boolean forward) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        AccessibilityNodeInfo n = find(root, (int) cx, (int) cy, mode);
        if (n == null) return;
        switch (mode) {
            case MODE_CLICK: n.performAction(AccessibilityNodeInfo.ACTION_CLICK); break;
            case MODE_LONG:  n.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK); break;
            default: n.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                                             : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        }
    }

    /** Deepest node under (x,y) that supports the requested action. */
    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, int x, int y, int mode) {
        if (node == null) return null;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.contains(x, y) && node.getChildCount() == 0) return null;
        for (int i = node.getChildCount() - 1; i >= 0; i--) {   // top-most child first
            AccessibilityNodeInfo hit = find(node.getChild(i), x, y, mode);
            if (hit != null) return hit;
        }
        if (!r.contains(x, y) || !node.isEnabled() || !node.isVisibleToUser()) return null;
        boolean ok = mode == MODE_CLICK ? node.isClickable()
                   : mode == MODE_LONG ? node.isLongClickable() : node.isScrollable();
        return ok ? node : null;
    }

    // ---------- views ----------
    private class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrow = new Path();
        CursorView(Context c) {
            super(c);
            fill.setColor(Color.WHITE);
            line.setColor(Color.BLACK); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2 * density);
            float d = density;
            arrow.moveTo(0, 0); arrow.lineTo(0, 22 * d); arrow.lineTo(6 * d, 17 * d);
            arrow.lineTo(11 * d, 28 * d); arrow.lineTo(15 * d, 26 * d); arrow.lineTo(10 * d, 15 * d);
            arrow.lineTo(18 * d, 15 * d); arrow.close();
        }
        @Override protected void onDraw(Canvas c) {
            c.save(); c.translate(cx, cy);
            c.drawPath(arrow, fill); c.drawPath(arrow, line);
            c.restore();
        }
    }

    private class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float downRawX, downRawY;
        private int startX, startY;
        private boolean moved;
        BubbleView(Context c) {
            super(c);
            fill.setColor(0xFF2979FF);
            ring.setColor(Color.WHITE); ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(2.5f * density);
        }
        @Override protected void onDraw(Canvas c) {
            float cx2 = getWidth() / 2f, cy2 = getHeight() / 2f, r = getWidth() / 2f - 3 * density;
            c.drawCircle(cx2, cy2, r, fill);
            c.drawCircle(cx2, cy2, r, ring);
            c.drawCircle(cx2, cy2, 4 * density, ring);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = e.getRawX(); downRawY = e.getRawY();
                    startX = bubbleParams.x; startY = bubbleParams.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downRawX, dy = e.getRawY() - downRawY;
                    if (!moved && Math.hypot(dx, dy) < 10 * density) break;
                    moved = true;
                    if (!prefs.getBoolean("bubble_lock", false)) {
                        bubbleParams.x = startX + (int) dx;
                        bubbleParams.y = startY + (int) dy;
                        clampBubble();
                        wm.updateViewLayout(this, bubbleParams);
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        togglePad();
                    } else if (!prefs.getBoolean("bubble_lock", false)) {
                        prefs.edit().putInt("bubble_x", bubbleParams.x)
                                    .putInt("bubble_y", bubbleParams.y).apply();
                    }
                    break;
            }
            return true;
        }
    }

    private class PadView extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG), edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float lx, ly, scrollAcc, travel;
        private long down;
        private boolean multi, dragging;
        private float downRawX, downRawY;
        private int startX, startY;

        PadView(Context c) {
            super(c);
            bg.setColor(0x55222222);
            edge.setColor(0x99FFFFFF); edge.setStyle(Paint.Style.STROKE); edge.setStrokeWidth(2 * density);
        }
        @Override protected void onDraw(Canvas c) {
            RectF r = new RectF(2 * density, 2 * density, getWidth() - 2 * density, getHeight() - 2 * density);
            c.drawRoundRect(r, 16 * density, 16 * density, bg);
            c.drawRoundRect(r, 16 * density, 16 * density, edge);
            float hh = 32 * density;
            c.drawLine(r.left + 12 * density, hh, r.right - 12 * density, hh, edge);
            for (int i = -1; i <= 1; i++)
                c.drawCircle(getWidth() / 2f + i * 14 * density, hh / 2f, 3 * density, edge);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) showCursor();
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) scheduleFade();

            if (a == MotionEvent.ACTION_DOWN && e.getY() < 32 * density) {
                dragging = true;
                downRawX = e.getRawX(); downRawY = e.getRawY();
                startX = padParams.x; startY = padParams.y;
                return true;
            }
            if (dragging) {
                if (a == MotionEvent.ACTION_MOVE) {
                    padParams.x = (int) Math.max(0, Math.min(sw - padSize, startX - (e.getRawX() - downRawX)));
                    padParams.y = (int) Math.max(0, Math.min(sh - padSize, startY - (e.getRawY() - downRawY)));
                    wm.updateViewLayout(pad, padParams);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    dragging = false;
                }
                return true;
            }
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                    lx = e.getX(); ly = e.getY(); travel = 0; scrollAcc = 0; multi = false;
                    down = e.getEventTime();
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    multi = true; ly = e.getY(); scrollAcc = 0;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getX() - lx, dy = e.getY() - ly;
                    lx = e.getX(); ly = e.getY();
                    travel += Math.abs(dx) + Math.abs(dy);
                    if (e.getPointerCount() >= 2) {
                        scrollAcc += dy;
                        if (Math.abs(scrollAcc) > 40 * density) {
                            act(MODE_SCROLL, scrollAcc < 0);
                            scrollAcc = 0;
                        }
                    } else if (!multi) {
                        cx = Math.max(0, Math.min(sw - 1, cx + dx * GAIN));
                        cy = Math.max(0, Math.min(sh - 1, cy + dy * GAIN));
                        if (cursor != null) cursor.invalidate();
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!multi && travel < 12 * density) {
                        long held = e.getEventTime() - down;
                        act(held >= 500 ? MODE_LONG : MODE_CLICK, true);
                    }
                    break;
            }
            return true;
        }
    }
}
