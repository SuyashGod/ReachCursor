package com.example.reachcursor;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import java.util.List;

public class CursorService extends AccessibilityService {
    private static final float GAIN = 2.6f;      // cursor speed vs. finger movement
    private static final int MODE_CLICK = 0, MODE_LONG = 1, MODE_SCROLL = 2, MODE_EDIT = 3;

    private WindowManager wm;
    private CursorView cursor;
    private PadView pad;
    private BubbleView bubble;
    private WindowManager.LayoutParams padParams, bubbleParams;
    private SharedPreferences prefs;
    private final Handler handler = new Handler();
    private boolean padShown;
    private int fadeMs = 3000;                   // 0 = never fade
    private float cx, cy, density;
    private int sw, sh, padW, padH, bubbleSize;
    private View typeBox;
    private View probe;                          // invisible view used to detect the nav bar
    private boolean bubbleAttached, navVisible, navSeen, followNav = true;

    private final Runnable fadeRunnable = new Runnable() {
        @Override public void run() {
            if (cursor != null) cursor.animate().alpha(0f).setDuration(400).start();
        }
    };

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
        new SharedPreferences.OnSharedPreferenceChangeListener() {
            @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                loadPrefs();
            }
        };

    @Override public void onServiceConnected() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density;
        cx = sw / 2f; cy = sh / 2f;

        // Cursor layer (full screen, never touchable)
        WindowManager.LayoutParams cp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        cursor = new CursorView(this);
        cursor.setAlpha(0f);
        wm.addView(cursor, cp);

        // Touchpad (added only when shown)
        padW = (int) (160 * density); padH = padW;
        padParams = new WindowManager.LayoutParams(
            padW, padH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        padParams.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        padParams.x = (int) (8 * density); padParams.y = (int) (8 * density);
        pad = new PadView(this);

        // Small round button that shows/hides the touchpad
        bubbleSize = (int) (44 * density);
        bubbleParams = new WindowManager.LayoutParams(
            bubbleSize, bubbleSize, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = prefs.getInt("bubble_x", sw - bubbleSize - (int) (8 * density));
        bubbleParams.y = prefs.getInt("bubble_y", sh / 2);
        clampBubble();
        bubble = new BubbleView(this);
        wm.addView(bubble, bubbleParams);
        bubbleAttached = true;

        // Invisible, untouchable view laid out inside the system bars. If it reaches the
        // bottom/right screen edge, the navigation bar is hidden.
        probe = new View(this);
        probe.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b,
                                                 int ol, int ot, int or2, int ob) {
                checkNav();
            }
        });
        WindowManager.LayoutParams pr = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT);
        wm.addView(probe, pr);

        loadPrefs();
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
    }

    private void loadPrefs() {
        if (prefs == null) return;
        fadeMs = prefs.getInt("fade_ms", 3000);
        followNav = prefs.getBoolean("bubble_follow_nav", true);
        if (bubble != null) bubble.setAlpha(prefs.getInt("bubble_alpha", 80) / 100f);
        applyPadSize();
        updateBubbleVisibility();
        if (padShown) { showCursor(); scheduleFade(); }
    }

    private void applyPadSize() {
        if (padParams == null) return;
        padW = Math.min(sw, (int) (prefs.getInt("pad_w", 160) * density));
        padH = Math.min(sh, (int) (prefs.getInt("pad_h", 160) * density));
        padParams.width = padW; padParams.height = padH;
        padParams.x = Math.max(0, Math.min(sw - padW, padParams.x));
        padParams.y = Math.max(0, Math.min(sh - padH, padParams.y));
        try { if (padShown) wm.updateViewLayout(pad, padParams); } catch (Exception ignored) { }
    }

    private void checkNav() {
        if (wm == null || probe == null) return;
        Point real = new Point();
        wm.getDefaultDisplay().getRealSize(real);
        int[] loc = new int[2];
        probe.getLocationOnScreen(loc);
        int right = loc[0] + probe.getWidth(), bottom = loc[1] + probe.getHeight();
        navVisible = right < real.x - 2 || bottom < real.y - 2;
        if (navVisible) navSeen = true;
        updateBubbleVisibility();
    }

    /** Circle is hidden only when the option is on AND we have seen the nav bar and it is now hidden. */
    private void updateBubbleVisibility() {
        if (bubble == null) return;
        boolean show = !followNav || !navSeen || navVisible;
        try {
            if (show && !bubbleAttached) {
                wm.addView(bubble, bubbleParams);
                bubbleAttached = true;
            } else if (!show && bubbleAttached) {
                if (padShown) togglePad();
                wm.removeView(bubble);
                bubbleAttached = false;
            }
        } catch (Exception ignored) { }
    }

    // ---------- cursor visibility ----------
    private void showCursor() {
        handler.removeCallbacks(fadeRunnable);
        if (cursor == null) return;
        cursor.animate().cancel();
        cursor.setAlpha(1f);
    }
    private void scheduleFade() {
        handler.removeCallbacks(fadeRunnable);
        if (fadeMs > 0) handler.postDelayed(fadeRunnable, fadeMs);
    }
    private void hideCursorNow() {
        handler.removeCallbacks(fadeRunnable);
        if (cursor == null) return;
        cursor.animate().cancel();
        cursor.setAlpha(0f);
    }

    private void togglePad() {
        try {
            if (padShown) {
                wm.removeView(pad);
                padShown = false;
                hideCursorNow();
            } else {
                wm.addView(pad, padParams);
                padShown = true;
                showCursor();
                scheduleFade();
            }
        } catch (Exception ignored) { }
    }

    private void clampBubble() {
        bubbleParams.x = Math.max(0, Math.min(sw - bubbleSize, bubbleParams.x));
        bubbleParams.y = Math.max(0, Math.min(sh - bubbleSize, bubbleParams.y));
    }

    @Override public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (wm == null) return;
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels; sh = dm.heightPixels;
        cx = Math.max(0, Math.min(sw - 1, cx));
        cy = Math.max(0, Math.min(sh - 1, cy));
        clampBubble();
        applyPadSize();
        try {
            if (bubbleAttached) wm.updateViewLayout(bubble, bubbleParams);
        } catch (Exception ignored) { }
        if (cursor != null) cursor.invalidate();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    @Override public boolean onUnbind(android.content.Intent i) {
        handler.removeCallbacks(fadeRunnable);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        try { if (cursor != null) wm.removeView(cursor); } catch (Exception ignored) { }
        try { if (padShown) wm.removeView(pad); } catch (Exception ignored) { }
        try { if (bubble != null && bubbleAttached) wm.removeView(bubble); } catch (Exception ignored) { }
        hideTypeBox();
        try { if (probe != null) wm.removeView(probe); } catch (Exception ignored) { }
        cursor = null; pad = null; bubble = null; probe = null; padShown = false; bubbleAttached = false;
        return super.onUnbind(i);
    }

    // ---------- actions at the cursor position ----------
    private void act(int mode, boolean forward) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        if (mode == MODE_LONG) {   // long-press on a text field opens the typing box
            AccessibilityNodeInfo ed = find(root, (int) cx, (int) cy, MODE_EDIT);
            if (ed != null) { showTypeBox(ed); return; }
        }
        AccessibilityNodeInfo n = find(root, (int) cx, (int) cy, mode);
        if (n == null) return;
        switch (mode) {
            case MODE_CLICK:
                if (n.isEditable()) editField(n);
                else n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                break;
            case MODE_LONG:  n.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK); break;
            default: n.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                                             : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        }
    }

    /** Focus a text field; if the system keyboard does not appear, open our own typing box. */
    private void editField(final AccessibilityNodeInfo n) {
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (keyboardMissing()) showTypeBox(n);
            }
        }, 450);
    }

    /** True only when we can read the window list and no keyboard window is in it. */
    private boolean keyboardMissing() {
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            if (ws == null || ws.isEmpty()) return false;     // unknown: do not interrupt
            for (AccessibilityWindowInfo w : ws)
                if (w.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD) return false;
            return true;
        } catch (Exception e) { return false; }
    }

    private void hideTypeBox() {
        try { if (typeBox != null) wm.removeView(typeBox); } catch (Exception ignored) { }
        typeBox = null;
    }

    /** Small panel with our own text field; OK writes the text into the chosen field. */
    private void showTypeBox(final AccessibilityNodeInfo target) {
        if (typeBox != null || wm == null) return;
        int p = (int) (10 * density);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xF2FFFFFF);
        box.setPadding(p, p, p, p);

        final EditText et = new EditText(this);
        et.setTextColor(Color.BLACK);
        et.setHint("Type here");
        et.setSingleLine(true);
        et.setImeOptions(EditorInfo.IME_ACTION_DONE);
        CharSequence cur = target.getText();
        if (cur != null) { et.setText(cur); et.setSelection(et.length()); }

        final Runnable apply = new Runnable() {
            @Override public void run() {
                final CharSequence txt = et.getText();
                hideTypeBox();
                handler.postDelayed(new Runnable() {
                    @Override public void run() {
                        Bundle args = new Bundle();
                        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, txt);
                        target.refresh();
                        target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
                    }
                }, 150);
            }
        };
        et.setOnEditorActionListener(new android.widget.TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(android.widget.TextView v, int id, KeyEvent ev) {
                apply.run(); return true;
            }
        });

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button ok = new Button(this); ok.setText("OK");
        Button cancel = new Button(this); cancel.setText("Cancel");
        ok.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { apply.run(); }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hideTypeBox(); }
        });
        row.addView(ok, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(cancel, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        box.addView(et);
        box.addView(row);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, 0, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                         | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
        try {
            wm.addView(box, lp);
            typeBox = box;
            et.requestFocus();
            et.postDelayed(new Runnable() {
                @Override public void run() {
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(et, 0);
                }
            }, 200);
        } catch (Exception ignored) { }
    }

    /** Deepest node under (x,y) that supports the requested action. */
    private AccessibilityNodeInfo find(AccessibilityNodeInfo node, int x, int y, int mode) {
        if (node == null) return null;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.contains(x, y) && node.getChildCount() == 0) return null;
        for (int i = node.getChildCount() - 1; i >= 0; i--) {   // top-most child first
            AccessibilityNodeInfo hit = find(node.getChild(i), x, y, mode);
            if (hit != null) return hit;
        }
        if (!r.contains(x, y) || !node.isEnabled() || !node.isVisibleToUser()) return null;
        boolean ok = mode == MODE_CLICK ? (node.isClickable() || node.isEditable())
                   : mode == MODE_LONG ? node.isLongClickable()
                   : mode == MODE_EDIT ? node.isEditable() : node.isScrollable();
        return ok ? node : null;
    }

    // ---------- views ----------
    private class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arrow = new Path();
        CursorView(Context c) {
            super(c);
            fill.setColor(Color.WHITE);
            line.setColor(Color.BLACK); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2 * density);
            float d = density;
            arrow.moveTo(0, 0); arrow.lineTo(0, 22 * d); arrow.lineTo(6 * d, 17 * d);
            arrow.lineTo(11 * d, 28 * d); arrow.lineTo(15 * d, 26 * d); arrow.lineTo(10 * d, 15 * d);
            arrow.lineTo(18 * d, 15 * d); arrow.close();
        }
        @Override protected void onDraw(Canvas c) {
            c.save(); c.translate(cx, cy);
            c.drawPath(arrow, fill); c.drawPath(arrow, line);
            c.restore();
        }
    }

    private class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float downRawX, downRawY;
        private int startX, startY;
        private boolean moved;
        BubbleView(Context c) {
            super(c);
            fill.setColor(0xFF2979FF);
            ring.setColor(Color.WHITE); ring.setStyle(Paint.Style.STROKE); ring.setStrokeWidth(2.5f * density);
        }
        @Override protected void onDraw(Canvas c) {
            float cx2 = getWidth() / 2f, cy2 = getHeight() / 2f, r = getWidth() / 2f - 3 * density;
            c.drawCircle(cx2, cy2, r, fill);
            c.drawCircle(cx2, cy2, r, ring);
            c.drawCircle(cx2, cy2, 4 * density, ring);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = e.getRawX(); downRawY = e.getRawY();
                    startX = bubbleParams.x; startY = bubbleParams.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downRawX, dy = e.getRawY() - downRawY;
                    if (!moved && Math.hypot(dx, dy) < 10 * density) break;
                    moved = true;
                    if (!prefs.getBoolean("bubble_lock", false)) {
                        bubbleParams.x = startX + (int) dx;
                        bubbleParams.y = startY + (int) dy;
                        clampBubble();
                        wm.updateViewLayout(this, bubbleParams);
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        togglePad();
                    } else if (!prefs.getBoolean("bubble_lock", false)) {
                        prefs.edit().putInt("bubble_x", bubbleParams.x)
                                    .putInt("bubble_y", bubbleParams.y).apply();
                    }
                    break;
            }
            return true;
        }
    }

    private class PadView extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG), edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float lx, ly, scrollAcc, travel;
        private long down;
        private boolean multi, dragging;
        private float downRawX, downRawY;
        private int startX, startY;

        PadView(Context c) {
            super(c);
            bg.setColor(0x55222222);
            edge.setColor(0x99FFFFFF); edge.setStyle(Paint.Style.STROKE); edge.setStrokeWidth(2 * density);
        }
        @Override protected void onDraw(Canvas c) {
            RectF r = new RectF(2 * density, 2 * density, getWidth() - 2 * density, getHeight() - 2 * density);
            c.drawRoundRect(r, 16 * density, 16 * density, bg);
            c.drawRoundRect(r, 16 * density, 16 * density, edge);
            float hh = 32 * density;
            c.drawLine(r.left + 12 * density, hh, r.right - 12 * density, hh, edge);
            for (int i = -1; i <= 1; i++)
                c.drawCircle(getWidth() / 2f + i * 14 * density, hh / 2f, 3 * density, edge);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) showCursor();
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) scheduleFade();

            if (a == MotionEvent.ACTION_DOWN && e.getY() < 32 * density) {
                dragging = true;
                downRawX = e.getRawX(); downRawY = e.getRawY();
                startX = padParams.x; startY = padParams.y;
                return true;
            }
            if (dragging) {
                if (a == MotionEvent.ACTION_MOVE) {
                    padParams.x = (int) Math.max(0, Math.min(sw - padW, startX - (e.getRawX() - downRawX)));
                    padParams.y = (int) Math.max(0, Math.min(sh - padH, startY - (e.getRawY() - downRawY)));
                    wm.updateViewLayout(pad, padParams);
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    dragging = false;
                }
                return true;
            }
            switch (a) {
                case MotionEvent.ACTION_DOWN:
                    lx = e.getX(); ly = e.getY(); travel = 0; scrollAcc = 0; multi = false;
                    down = e.getEventTime();
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    multi = true; ly = e.getY(); scrollAcc = 0;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getX() - lx, dy = e.getY() - ly;
                    lx = e.getX(); ly = e.getY();
                    travel += Math.abs(dx) + Math.abs(dy);
                    if (e.getPointerCount() >= 2) {
                        scrollAcc += dy;
                        if (Math.abs(scrollAcc) > 40 * density) {
                            act(MODE_SCROLL, scrollAcc < 0);
                            scrollAcc = 0;
                        }
                    } else if (!multi) {
                        cx = Math.max(0, Math.min(sw - 1, cx + dx * GAIN));
                        cy = Math.max(0, Math.min(sh - 1, cy + dy * GAIN));
                        if (cursor != null) cursor.invalidate();
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                    if (!multi && travel < 12 * density) {
                        long held = e.getEventTime() - down;
                        act(held >= 500 ? MODE_LONG : MODE_CLICK, true);
                    }
                    break;
            }
            return true;
        }
    }
}
