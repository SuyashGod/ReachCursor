package com.example.reachcursor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    static final String PREFS = "settings";
    private static final String[] LABELS = {"1 second", "2 seconds", "3 seconds", "5 seconds", "Off (cursor always visible)"};
    private static final int[] VALUES = {1000, 2000, 3000, 5000, 0};

    private SharedPreferences prefs;
    private Button fadeBtn;
    private float d;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        d = getResources().getDisplayMetrics().density;
        int p = (int) (20 * d);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(p, p, p, p);

        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Reach Cursor\n\n1. Tap \"Open Accessibility settings\", open Reach Cursor and switch it ON.\n"
            + "2. A small blue circle appears. Tap it to show or hide the touchpad.\n\n"
            + "\u2022 Drag the circle = move it anywhere\n"
            + "\u2022 Drag the top strip (dots) of the pad = move the pad\n"
            + "\u2022 Drag on the pad = move the cursor\n"
            + "\u2022 Tap = click, press and hold = long-press\n"
            + "\u2022 Two-finger drag up/down = scroll\n"
            + "\u2022 Double-tap the pad = lock the click (cursor turns orange). Move the cursor to slide a bar or scroll, then double-tap again to release\n"
            + "\u2022 Tap keys on the on-screen keyboard and the bottom bar buttons with the cursor\n");
        l.addView(t);

        Button acc = new Button(this);
        acc.setText("Open Accessibility settings");
        acc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        l.addView(acc);

        fadeBtn = new Button(this);
        updateFadeLabel();
        fadeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showFadeDialog(); }
        });
        l.addView(fadeBtn);

        slider(l, "Circle opacity", "%", "bubble_alpha", 20, 100, 80);
        slider(l, "Touchpad width", " dp", "pad_w", 100, 320, 160);
        slider(l, "Touchpad height", " dp", "pad_h", 100, 320, 160);

        CheckBox dl = new CheckBox(this);
        dl.setText("Double-tap on pad locks the click (slide / scroll)");
        dl.setChecked(prefs.getBoolean("drag_lock_enabled", true));
        dl.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton c, boolean on) {
                prefs.edit().putBoolean("drag_lock_enabled", on).apply();
            }
        });
        l.addView(dl);

        check(l, "Reverse slide direction - horizontal", "drag_reverse_h", true);
        check(l, "Reverse slide direction - vertical", "drag_reverse_v", false);
        slider(l, "Sensitivity of slider (horizontal)", "%", "drag_sens_h", 10, 300, 100);
        slider(l, "Sensitivity of slider (vertical)", "%", "drag_sens_v", 10, 300, 100);

        CheckBox lock = new CheckBox(this);
        lock.setText("Lock circle position");
        lock.setChecked(prefs.getBoolean("bubble_lock", false));
        lock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton c, boolean on) {
                prefs.edit().putBoolean("bubble_lock", on).apply();
            }
        });
        l.addView(lock);

        CheckBox nav = new CheckBox(this);
        nav.setText("Hide circle when the bottom navigation bar is hidden");
        nav.setChecked(prefs.getBoolean("bubble_follow_nav", true));
        nav.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton c, boolean on) {
                prefs.edit().putBoolean("bubble_follow_nav", on).apply();
            }
        });
        l.addView(nav);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }

    private void check(LinearLayout root, String text, final String key, boolean def) {
        CheckBox cb = new CheckBox(this);
        cb.setText(text);
        cb.setChecked(prefs.getBoolean(key, def));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton c, boolean on) {
                prefs.edit().putBoolean(key, on).apply();
            }
        });
        root.addView(cb);
    }

    /** Adds a labelled slider that saves to prefs immediately (the service updates live). */
    private void slider(LinearLayout root, final String label, final String unit, final String key,
                        final int min, int max, int def) {
        final TextView tv = new TextView(this);
        tv.setPadding(0, (int) (16 * d), 0, 0);
        root.addView(tv);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        int cur = prefs.getInt(key, def);
        sb.setProgress(cur - min);
        tv.setText(label + ": " + cur + unit);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int v = prog + min;
                tv.setText(label + ": " + v + unit);
                prefs.edit().putInt(key, v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(sb);
    }

    private void updateFadeLabel() {
        int cur = prefs.getInt("fade_ms", 3000);
        String s = LABELS[2];
        for (int i = 0; i < VALUES.length; i++) if (VALUES[i] == cur) s = LABELS[i];
        fadeBtn.setText("Hide cursor after: " + s);
    }

    private void showFadeDialog() {
        int cur = prefs.getInt("fade_ms", 3000), sel = 2;
        for (int i = 0; i < VALUES.length; i++) if (VALUES[i] == cur) sel = i;
        new AlertDialog.Builder(this)
            .setTitle("Hide cursor after")
            .setSingleChoiceItems(LABELS, sel, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dlg, int which) {
                    prefs.edit().putInt("fade_ms", VALUES[which]).apply();
                    updateFadeLabel();
                    dlg.dismiss();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
