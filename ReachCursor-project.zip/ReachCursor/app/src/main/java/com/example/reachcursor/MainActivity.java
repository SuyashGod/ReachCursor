package com.example.reachcursor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        l.setPadding(p, p, p, p);
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Reach Cursor\n\n1. Tap the button below.\n2. Open \"Reach Cursor\" and switch it ON.\n\n"
            + "A touchpad appears at the bottom-right corner:\n"
            + "\u2022 Drag the top strip (dots) = move the pad\n" + "\u2022 Drag = move the cursor\n"
            + "\u2022 Tap = click at the cursor\n"
            + "\u2022 Press and hold, then release = long-press\n"
            + "\u2022 Two-finger drag up/down = scroll\n\n"
            + "To remove it, switch the service OFF.");
        Button btn = new Button(this);
        btn.setText("Open Accessibility settings");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        l.addView(t);
        l.addView(btn);
        setContentView(l);
    }
}
