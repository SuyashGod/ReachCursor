package com.example.reachcursor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    static final String PREFS = "settings";
    private static final String[] LABELS = {"1 second", "2 seconds", "3 seconds", "5 seconds", "Off (cursor always visible)"};
    private static final int[] VALUES = {1000, 2000, 3000, 5000, 0};

    private SharedPreferences prefs;
    private Button fadeBtn;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        final float d = getResources().getDisplayMetrics().density;
        int p = (int) (20 * d);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(p, p, p, p);

        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("Reach Cursor\n\n1. Tap \"Open Accessibility settings\", open Reach Cursor and switch it ON.\n"
            + "2. A small blue circle appears. Tap it to show or hide the touchpad.\n\n"
            + "\u2022 Drag the circle = move it anywhere\n"
            + "\u2022 Drag the top strip (dots) of the pad = move the pad\n"
            + "\u2022 Drag on the pad = move the cursor\n"
            + "\u2022 Tap = click, press and hold = long-press\n"
            + "\u2022 Two-finger drag up/down = scroll\n");
        l.addView(t);

        Button acc = new Button(this);
        acc.setText("Open Accessibility settings");
        acc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        l.addView(acc);

        fadeBtn = new Button(this);
        updateFadeLabel();
        fadeBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showFadeDialog(); }
        });
        l.addView(fadeBtn);

        final TextView opLabel = new TextView(this);
        opLabel.setPadding(0, (int) (16 * d), 0, 0);
        l.addView(opLabel);
        SeekBar sb = new SeekBar(this);
        sb.setMax(80);                                   // 20% .. 100%
        int alpha = prefs.getInt("bubble_alpha", 80);
        sb.setProgress(alpha - 20);
        opLabel.setText("Circle opacity: " + alpha + "%");
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean user) {
                int a = prog + 20;
                opLabel.setText("Circle opacity: " + a + "%");
                prefs.edit().putInt("bubble_alpha", a).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        l.addView(sb);

        CheckBox lock = new CheckBox(this);
        lock.setText("Lock circle position");
        lock.setChecked(prefs.getBoolean("bubble_lock", false));
        lock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton c, boolean on) {
                prefs.edit().putBoolean("bubble_lock", on).apply();
            }
        });
        l.addView(lock);

        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        setContentView(sv);
    }

    private void updateFadeLabel() {
        int cur = prefs.getInt("fade_ms", 3000);
        String s = LABELS[2];
        for (int i = 0; i < VALUES.length; i++) if (VALUES[i] == cur) s = LABELS[i];
        fadeBtn.setText("Hide cursor after: " + s);
    }

    private void showFadeDialog() {
        int cur = prefs.getInt("fade_ms", 3000), sel = 2;
        for (int i = 0; i < VALUES.length; i++) if (VALUES[i] == cur) sel = i;
        new AlertDialog.Builder(this)
            .setTitle("Hide cursor after")
            .setSingleChoiceItems(LABELS, sel, new android.content.DialogInterface.OnClickListener() {
                @Override public void onClick(android.content.DialogInterface dlg, int which) {
                    prefs.edit().putInt("fade_ms", VALUES[which]).apply();
                    updateFadeLabel();
                    dlg.dismiss();
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
